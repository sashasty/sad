<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <link rel="stylesheet" href="/assets/css/bootstrap.min.css" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css"/>
  <link rel="stylesheet" href="/assets/css/dataTables.bootstrap5.min.css" />
  <link rel="stylesheet" href="/assets/css/enter.css" />
  <link rel="shortcut icon" href="/assets/images/icon.ico" type="image/x-icon">
  <title><?=$title?></title>
</head>
<body>
